import java.util.*;

class Messages {
    public static final String SANS_PREDECESSEUR = 
	"Cet entier naturel vaut zéro : il n'a pas de prédécesseur."; 
    public static final String INT_NON_NATUREL = 
	" est un entier strictement négatif. Il devrait être positif ou nul.";
    public static final String NAT_MUTABLE = 
	" est un entier naturel mutable. Il devrait être immutable.";
    public static final String NAT_NON_MUTABLE = 
	" n'est pas un entier naturel mutable. Il devrait être mutable.";
    public static final String Z_MUTABLE = 
	" est un entier relatif mutable. Il devrait être immutable.";
    public static final String Z_NON_MUTABLE = 
	" n'est pas un entier relatif mutable. Il devrait être mutable.";
    public static final String FABNAT_MUTABLE = 
	" est une fabrique d'entiers naturels mutables. Ils devraient être immutables.";
    public static final String FABNAT_IMMUTABLE = 
	" est une fabrique d'entiers naturels immutables. Ils devraient être mutables.";
    public static final String REEL_MUTABLE = 
	" est un réel mutable. Il devrait être immutable.";
    public static final String REEL_NON_MUTABLE = 
	" n'est pas un réel mutable. Il devrait être mutable.";
    public static final String RATIONNEL_MUTABLE = 
	" est un rationnel mutable. Il devrait être immutable.";
    public static final String RATIONNEL_NON_MUTABLE = 
	" n'est pas un rationnel mutable. Il devrait être mutable.";
    public static final String DOUBLE_SANS_PARTIE_ENTIERE = " n'a pas de partie entière calculable par un int.";
    public static final String FABREEL_MUTABLE = 
	" est une fabrique de réels mutables. Ils devraient être immutables.";
    public static final String FABREEL_IMMUTABLE = 
	" est une fabrique de réels immutables. Ils devraient être mutables.";
    public static final String FABZ_MUTABLE = 
	" est une fabrique d'entiers relatifs mutables. Ils devraient être immutables.";
    public static final String FABZ_IMMUTABLE = 
	" est une fabrique d'entiers relatifs immutables. Ils devraient être mutables.";
    public static final String FABRAT_INEFFICACE = 
	" est une fabrique de rationnels symboliques (implémentés par des fractions). Ils devraient être implémentés par des quotients.";
    public static final String FABRAT_EFFICACE = 
	" est une fabrique de rationnels efficaces (implémentés par des quotients). Ils devraient être implémentés par des fractions.";
}

interface SemiAnneauNat {
    Nat somme(Nat x);
    Nat zero();
    Nat produit(Nat x);
    Nat un();
}

interface NombreNaturel {
    int val(); // Convertit l'entier naturel en int   
    boolean estNul(); // Teste à zéro l'entier naturel
    NombreNaturel predecesseur(); // Donne le prédécesseur s'il existe
}

interface FabriqueNat {
    Nat creer(int val); // Crée un entier valant val (supposé positif) 
    Nat creer(); // Crée un entier valant zéro 
    Nat creer(Nat predecesseur); // Crée un entier naturel égal au successeur de pred
}

interface Nat extends NombreNaturel, FabriqueNat, SemiAnneauNat {
    Nat predecesseur(); // Donne le prédécesseur s'il existe (spécialisation)
    boolean equals(Object o); // Renvoie false
    //   si o n'est pas de type Nat,
    // teste l'égalité des entiers naturels sinon
    String toString(); // Affiche l'entier renvoyé par val()
}

// TODO - bottom up - bas - immutable - classe IntPositif

// TODO : bottom up - haut - immutable - classe NatParIntPositif

/*
 * Interface utilisée pour étiqueter les données mutables (ou les fabriques de données mutables).
 */
interface Mutable {}

// TODO - bottom up - haut - mutable - classe NatMutableParIntPositif

// TODO (compléter) classe FabriquerNat
class FabriquerNat {
    public static final FabriqueNat MUTABLE = null;
    public static final FabriqueNat IMMUTABLE = null;
    public static Nat mutable(Nat n){
	if(!(n instanceof Mutable)){
	    return MUTABLE.creer(n.val());
	}else{
	    throw new IllegalArgumentException(n + Messages.NAT_MUTABLE);
	}
    }
    public static Nat immutable(Nat n){
	if(n instanceof Mutable){
	    return IMMUTABLE.creer(n.val());
	}else{
	    throw new IllegalArgumentException(n + Messages.NAT_NON_MUTABLE);
	}
    }
}

interface Relatif {
    int val(); // Convertit en un int
    boolean estPositif(); // Teste si l'entier relatif est positif
    boolean estNegatif(); // Teste si l'entier relatif est négatif
    Nat valAbsolue(); // Renvoie la valeur absolue de l'entier relatif
    Nat diminuende(); // Renvoie le diminuende associé à l'entier relatif 
    Nat diminuteur(); // Renvoie le diminuteur associé à l'entier relatif 
}

interface FabriqueZ {
    Z creer(boolean signe, Nat abs); // Crée un entier relatif de signe et de valeur absolue donnés
    Z creer(Nat diminuende, Nat diminuteur); // Crée un entier relatif correspondant 
                                             //   à la différence diminuende - diminuteur  
    Z creer(int val); // Crée un entier relatif valant val
}

interface AnneauZ {
    Z somme(Z a);
    Z zero();
    Z oppose();
    Z produit(Z a);
    Z un();
}

interface Z extends Relatif, FabriqueZ, AnneauZ {
    boolean equals(Object o); // Renvoie false
    //   si o n'est pas de type Z,
    // teste l'égalité des entiers relatifs sinon
    String toString(); // Représente l'entier relatif sous la forme d'un int
}

/*
 * Interface utilisée pour étiqueter les données réalisant des calculs de manière efficace.
 * (efficace = utilisant directement un type Java sous-jacent)
 */
interface Efficace {}

// TODO top down - haut - immutable - classe ZEfficace


// TODO top down - bas - immutable - classe ZEfficaceParInt
class ZEfficaceParInt extends ZEfficace {
    // Dépendance relative à une fabrique d'entiers naturels
    private static FabriqueNat fabNat = FabriquerNat.IMMUTABLE;

    public static void setFabriqueNat(FabriqueNat fabNat){
	if(fabNat instanceof Mutable){
	    throw new IllegalArgumentException(fabNat + Messages.FABNAT_MUTABLE);
	}
	ZEfficaceParInt.fabNat = fabNat;
    }
    

}

// TODO top down - haut - mutable - classe ZEfficaceMutable

// TODO top down - bas - mutable - class ZEfficaceMutableParInt

// TODO (compléter) classe FabriquerZ
class FabriquerZ {
    public static final FabriqueZ IMMUTABLE = null; 
    public static final FabriqueZ MUTABLE = null;
    public static Z mutable(Z n){
	if(!(n instanceof Mutable)){

	}else{
	    throw new IllegalArgumentException(n + Messages.Z_MUTABLE);
	}
    }
    public static Z immutable(Z n){
	if(n instanceof Mutable){

	}else{
	    throw new IllegalArgumentException(n + Messages.Z_NON_MUTABLE);
	}
    }
}

interface FabriqueReel {
    Reel creer(double r);
}

interface CorpsReel {
    Reel somme(Reel a);
    Reel zero();
    Reel oppose();
    Reel produit(Reel a);
    Reel un();
    Reel inverse();
}

interface Reel extends FabriqueReel, CorpsReel {
    double val();
}

// TODO - Agrégation simple - immutable - classe ReelParDouble
class ReelParDouble implements Reel {
    private static double PRECISION = 1e-12; // Précision relative lors des tests d'égalité.
}

// TODO - Agrégation simple - mutable - classe ReelMutableParDouble


// TODO (compléter) - classe FabriquerReel
class FabriquerReel {

}

interface Rationnel {
    Z numerateur(); // Renvoie le numérateur
    Z denominateur(); // Renvoie le dénominateur
    Reel quotient(); // Renvoie le quotient
}

interface FabriqueQ {
    Q creer(Z numerateur, Z denominateur); // Crée le rationnel "numerateur"/"denominateur"
    Q creer(Reel rationnel); // // Crée le rationnel de valeur réelle "rationnel"
}

interface CorpsQ {
    Q somme(Q a);
    Q zero();
    Q oppose();
    Q produit(Q a);
    Q un();
    Q inverse();
}

interface Q extends Rationnel, FabriqueQ, CorpsQ {
    boolean equals(Object o); // Renvoie false
                              //   si o n'est pas de type Q,
                              // teste l'égalité des rationnels sinon
    String toString(); // Représente le rationnel sous la forme "numerateur/denominateur"
}


// TODO - agrégation avec délégation - bas - classe RationnelParQuotient
class RationnelParQuotient implements Rationnel, Efficace {
    private FabriqueReel fabR; //  fabrique de réels
    private FabriqueZ fabZ; // fabrique d'entiers relatifs

    
}

// TODO - agrégation avec délégation - bas - classe RationnelParFraction
class RationnelParFraction implements Rationnel {
    private FabriqueReel fabR; //  fabrique de réels
    private FabriqueZ fabZ; // fabrique d'entiers relatifs

}

interface FabriqueRationnel {
    Rationnel creer(Z numerateur, Z denominateur, FabriqueReel fabR, FabriqueZ fabZ);
    Rationnel creer(Reel rationnel, FabriqueReel fabR, FabriqueZ fabZ);
}

// TODO - implémentation de fabriques par des classes singletons FabriqueFraction et  FabriqueQuotient


// TODO (compléter) agrégation avec délégation - haut - classe abstraite QAbstrait (factorisation de la délégation)
abstract class QAbstrait implements Q {
    abstract public Q creer(Z numerateur, Z denominateur);
    abstract public Q creer(Reel rationnel);
    abstract public Q somme(Q a);
    abstract public Q zero();
    abstract public Q oppose();
    abstract public Q produit(Q a);
    abstract public Q un();
    abstract public Q inverse();
}

// TODO - agrégation avec délégation - haut - immutable, efficace - classe QEfficace
class QEfficace extends QAbstrait implements Q, Efficace {

    private static FabriqueRationnel fabRat = FabriqueQuotient.SINGLETON;
    private static FabriqueReel fabR = FabriquerReel.IMMUTABLE;
    private static FabriqueZ fabZ = FabriquerZ.IMMUTABLE;

    public static void setFabriqueRationnel(FabriqueRationnel fabRat){
	QEfficace.fabRat = fabRat;
    }
    public static void setFabriqueReel(FabriqueReel fabR){
	if(fabR instanceof Mutable){
	    throw new IllegalArgumentException(fabR + Messages.FABREEL_MUTABLE);
	}
	QEfficace.fabR = fabR;
    }
    public static void setFabriqueZ(FabriqueZ fabZ){
	if(fabZ instanceof Mutable){
	    throw new IllegalArgumentException(fabZ + Messages.FABZ_MUTABLE);
	}
	QEfficace.fabZ = fabZ;
    }

}

// TODO - agrégation avec délégation - haut - immutable, symbolique - classe QSymbolique


// TODO - agrégation avec délégation - haut - mutable, efficace - classe QMutableEfficace


// TODO - agrégation avec délégation - haut - mutable, symbolique - classe QMutableSymbolique


// TODO (compléter) - Fabriques de rationnels
class FabriquerQ {
    public static final FabriqueQ SYMBOLIQUE = null
	public static final FabriqueQ EFFICACE = null;
    public static final FabriqueQ MUTABLE_SYMBOLIQUE = null;
    public static final FabriqueQ MUTABLE_EFFICACE = null;
    public static Q mutable(Q x){
	if(!(x instanceof Mutable)){
	    return (x instanceof Efficace) ? 
		MUTABLE_EFFICACE.creer(FabriquerReel.mutable(x.quotient())) :
		MUTABLE_SYMBOLIQUE.creer(FabriquerZ.mutable(x.numerateur()), 
					 FabriquerZ.mutable(x.denominateur())) ;
	}else{
	    throw new IllegalArgumentException(x + Messages.RATIONNEL_MUTABLE);
	}
    }
    public static Q immutable(Q x){
	if(x instanceof Mutable){
	    return (x instanceof Efficace) ? 
		EFFICACE.creer(FabriquerReel.immutable(x.quotient())) :
		SYMBOLIQUE.creer(FabriquerZ.immutable(x.numerateur()), 
				 FabriquerZ.immutable(x.denominateur())) ;
	}else{
	    throw new IllegalArgumentException(x + Messages.RATIONNEL_NON_MUTABLE);
	}
    }
}


public class TP1 {
    private static boolean mutable = false;
    private static boolean efficace = false;
    private static boolean fraction = false;
    public static void main(String[] args){
	if(args[0].equals("m")) {
	    System.out.println("mutable");
	    mutable = true;
	}else{
	    System.out.println("immutable");
	    mutable = false;
	}
	if(args[1].equals("e")) {
	    System.out.println("efficace");
	    efficace = true;
	}else{
	    System.out.println("symbolique");
	    efficace = false;
	}
	if(args[2].equals("f")) {
	    System.out.println("fraction");
	    fraction = true;
	}else{
	    System.out.println("quotient");
	    fraction = false;
	}
	if(mutable && efficace && fraction){
	    System.out.println("option non reconnue.");
	    System.exit(1);
	}
	if(mutable && !efficace && !fraction){
	    System.out.println("option non reconnue.");
	    System.exit(1);
	}
	FabriqueNat fabN = mutable ? FabriquerNat.MUTABLE : FabriquerNat.IMMUTABLE;
	System.out.println("**** Test de " + fabN.getClass() + "  ****");
	test(fabN);
	FabriqueZ fabZ = mutable ? FabriquerZ.MUTABLE : FabriquerZ.IMMUTABLE;
	System.out.println("**** Test de " + fabZ.getClass() + "  ****");
	test(fabN, fabZ);

	FabriqueReel fabR = mutable ? FabriquerReel.MUTABLE : FabriquerReel.IMMUTABLE;

	FabriqueRationnel fabRat = fraction ? FabriqueFraction.SINGLETON : FabriqueQuotient.SINGLETON;
	if(!mutable){
	    QEfficace.setFabriqueRationnel(fabRat);
	    QEfficace.setFabriqueReel(fabR);
	    QEfficace.setFabriqueZ(fabZ);
	    QSymbolique.setFabriqueRationnel(fabRat);
	    QSymbolique.setFabriqueReel(fabR);
	    QSymbolique.setFabriqueZ(fabZ);
	}else{
	    if(efficace){
		QMutableEfficace.setFabriqueRationnel(fabRat);
		QMutableEfficace.setFabriqueReel(fabR);
		QMutableEfficace.setFabriqueZ(fabZ);
	    }else{
		QMutableSymbolique.setFabriqueRationnel(fabRat);
		QMutableSymbolique.setFabriqueReel(fabR);
		QMutableSymbolique.setFabriqueZ(fabZ);
	    }
	}
	FabriqueQ fabQ = efficace ? 
	    (mutable ? FabriquerQ.MUTABLE_EFFICACE : FabriquerQ.EFFICACE) :
	    (mutable ? FabriquerQ.MUTABLE_SYMBOLIQUE : FabriquerQ.SYMBOLIQUE) ;
	
	System.out.println("**** Test de " + fabQ.getClass()  + " et de " + fabRat.getClass() + "  ****"); 
	test(fabZ, fabR, fabQ);

    }
    private static void test(FabriqueNat fabrique){
	Nat x = null;
	Nat zero = fabrique.creer();
	System.out.println("0 ? " + zero);
	x = fabrique.creer();
	System.out.println("true ? " + zero.equals(x.zero()));
	Nat un = fabrique.creer(zero);
	System.out.println("1 ? " + un);
	x = fabrique.creer();
	System.out.println("true ? " + un.equals(x.un()));
	Nat cinq = fabrique.creer(5);
	System.out.println("5 ? " + cinq);
	x = fabrique.creer(cinq);
	System.out.println("6 ? " + x);
	x = x.somme(cinq);
	System.out.println("11 ? " + x);
	x = x.produit(cinq);
	System.out.println("55 ? " + x);
	x = x.zero();
	for(int i = 0; i < 100000000; i++){
	    x = x.somme(cinq);
	}
	System.out.println((5 * 100000000) + " ? " + x);
	if(mutable){
	    System.out.println(FabriquerNat.immutable(x));
	}else{
	    System.out.println(FabriquerNat.mutable(x));
	}
    }
    private static void test(FabriqueNat fabN, FabriqueZ fabrique){
	Z x = null;
	Z zero = fabrique.creer(0);
	System.out.println("0 | 0 - 0 ? " + zero);
	x = fabrique.creer(2);
	System.out.println("0 = 0 ? " + zero.equals(x.zero()));
	zero = fabrique.creer(true, fabN.creer());
	System.out.println("0 | 0 - 0 ? " + zero);
	System.out.println("0 = 0 ? " + zero.equals(x.zero()));
	zero = fabrique.creer(fabN.creer(), fabN.creer());
	System.out.println("0 | 0 - 0 ? " + zero);
	System.out.println("0 = 0 ? " + zero.equals(x.zero()));

	Z un = fabrique.creer(1);
	System.out.println("1 | 1 - 0 ? " + un);
	System.out.println("1 = 1 ? " + un.equals(x.un()));
	un = fabrique.creer(true, fabN.creer(1));
	System.out.println("1 | 1 - 0 ? " + un);
	System.out.println("1 = 1 ? " + un.equals(x.un()));
	un = fabrique.creer(fabN.creer(1), fabN.creer());
	System.out.println("1 | 1 - 0 ? " + un);
	System.out.println("1 = 1 ? " + un.equals(x.un()));

	Z moinsUn = fabrique.creer(- 1);
	System.out.println("-1 | 0 - 1 ? " + moinsUn);
	System.out.println("-1 = -1 ? " + moinsUn.equals(x.un().oppose()));
	moinsUn = fabrique.creer(false, fabN.creer(1));
	System.out.println("-1 | 0 - 1 ? " + moinsUn);
	System.out.println("-1 = -1 ? " + moinsUn.equals(x.un().oppose()));
	System.out.println("-1 | 0 - 1 ? " + moinsUn);
	System.out.println("-1 = -1 ? " + moinsUn.equals(x.un().oppose()));

	Z moinsCinq = fabrique.creer(- 5);
	System.out.println("-5 | 0 - 5 ? " + moinsCinq);
	Z six = fabrique.creer(6);
	System.out.println("6 | 6 - 0 ? " + six);
	x = x.zero();
	x = x.somme(moinsCinq).somme(six);
	System.out.println("1 | 6 - 5 ? " + x);
	System.out.println("1 | 61 - 60 ? " + x.produit(x));
	x = x.un();
	x = x.produit(moinsCinq).produit(six);
	System.out.println("-30 | 0 - 30 ? " + x);
	System.out.println("-30 <= 0 ? " + x.estNegatif());
	System.out.println("-30 >= 0 ? " + x.estPositif());
	System.out.println("0 - 30 ? " + x.diminuende() + " - " + x.diminuteur());
	x = x.zero();
	for(int i = 0; i < 100000000; i++){
	    x = x.somme(moinsUn);
	}
	System.out.println((-1 * 100000000) + " ? " + x);
	if(mutable){
	    System.out.println(FabriquerZ.immutable(x));
	}else{
	    System.out.println(FabriquerZ.mutable(x));
	}
    }

    private static void test(FabriqueZ fabZ, FabriqueReel fabR, FabriqueQ fabQ){
	Q x = null;
	Z moinsUn = fabZ.creer(-1);
	Z moinsDeux = fabZ.creer(-2);
	Q unDemi = fabQ.creer(moinsUn, moinsDeux);
	System.out.println("-1/-2 ou 0.5 ? " + unDemi);
	Q deuxQ = fabQ.creer(moinsDeux, moinsUn);
	System.out.println("-2/-1 ou 2 ? " + deuxQ);
	x = fabQ.creer(deuxQ.quotient());
	x = x.inverse();
	System.out.println("1/2 ou 0.5 ? "+ x);
	System.out.println("1/2 = 1/2 ? " + unDemi.equals(x));
	x = x.somme(unDemi);
	System.out.println("1 ? " + x);
	x = x.somme(fabQ.creer(fabR.creer(-0.5)));
	x = x.produit(unDemi);
	System.out.println("1/4 ou 0.25 ? " + x);
	x = fabQ.creer(fabR.creer(0));
	for(int i = 0; i < 100000000; i++){
	    x = x.somme(deuxQ);
	}
	System.out.println((2 * 100000000) + " ? " + x);
	if(x instanceof Mutable){
	    System.out.println(FabriquerQ.immutable(x));
	}else{
	    System.out.println(FabriquerQ.mutable(x));
	}

    }
    
}
